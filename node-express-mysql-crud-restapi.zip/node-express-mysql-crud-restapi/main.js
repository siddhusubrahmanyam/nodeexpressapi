const express = require('express');
const todos = require('./app/controllers/todo.controller.js');  
const bodyParser = require('body-parser');
// const authRoutes = require('./routes/auth');
// const protectedRoute = require('./routes/protectedRoute');
//create express app
const app = express();

//  app.use(express.json());
//  app.get('/auth', authRoutes);
//  app.get('/protected', protectedRoute);
//parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }))

//parse application/json
app.use(bodyParser.json())

//define a simple route
app.get('/', (req, res) => {
    res.json({"message": "Welcome to todo app"});
});
require('./app/routes/todo.routes.js')(app);

//listen for requests
app.listen(4000, () => {
    console.log('Server is on port 4000');
});